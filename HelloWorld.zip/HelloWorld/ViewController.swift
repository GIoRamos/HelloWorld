//
//  ViewController.swift
//  HelloWorld
//
//  Created by GIOVANNI GARCIA on 9/17/18.
//  Copyright © 2018 GIOVANNI GARCIA. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var imageView: UIImageView!
    
    
    var liverPoolLogo = #imageLiteral(resourceName: "liverpool-logo")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imageView.image = liverPoolLogo}
        
    }

   





